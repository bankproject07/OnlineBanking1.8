package com.cg.obs.service;

import java.util.List;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;

public interface IUserService {

	public Users getUser(int id) throws UserException;
	public Admin getAdmin(String id) throws UserException;
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException;
	public List<Transactions> getDetailedTransactions(Long accountno) throws UserException;
	public void updateCustomerDetails(Customer customer) throws UserException;
	public int requestService(ServiceTracker services) throws UserException;
	public int fundTransfer(FundTransfer transferInfo) throws UserException;
	public void changePassword(Users user) throws UserException;
	public void updateLockStatus(int userid) throws UserException;
}
