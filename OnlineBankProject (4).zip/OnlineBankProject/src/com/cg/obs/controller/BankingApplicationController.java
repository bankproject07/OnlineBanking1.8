package com.cg.obs.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;
import com.cg.obs.service.UserServiceImpl;


@WebServlet(urlPatterns={"/BankingApplicationController","/Login","/GetMiniTransactions"})
public class BankingApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IUserService userService;
    public BankingApplicationController() {
        
    	userService=new UserServiceImpl();
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path=request.getServletPath();
		String url="";
		
		switch(path)
		{
		case "/Login":
			
			String id=request.getParameter("username");
			String password=request.getParameter("password");
			
			int hitCounter=0;
			Users user=userService.getUser(Integer.parseInt(id));
			System.out.println(user);
			if(user!=null)
				{
				if(user.getLockStatus()!="L")
					
				{
					
					if(password.equalsIgnoreCase(user.getLoginPassword()))
					{
						System.out.println(user.getLoginPassword());
						url="Projects/index.jsp";
						
						/*request.setAttribute("userid", user.getUserId());
						request.setAttribute("accountno", user.getAccountId());*/
						HttpSession session=request.getSession();
						session.setAttribute("accountno", user.getAccountId());
						
						}
					else
					{
						hitCounter++;
						System.out.println(hitCounter);
						if(hitCounter==3)
						{
							userService.updateLockStatus(user.getUserId());
							System.out.println("Your Account Locked");
							
							throw new UserException("Your Account is locked");
						}
					url="#"; 
					}
				}
				else
				{
					System.out.println("Wrong Password"+hitCounter);
				}
				}
			else
			{
				throw new UserException("No User Exists.....");
			}
				
			break;
			
		case "/GetMiniTransactions":
			
			String accountid=(String)request.getAttribute("accountno");
			System.out.println("In getminitrans accountno:"+accountid);
			Long accountno=Long.parseLong(accountid);
			List<Transactions> miniTransList=userService.getMiniTransactions(accountno);
			
			request.setAttribute("miniTransList", miniTransList);
			url="Projects/pages/MiniTransactions.jsp";
			break;
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
				
			RequestDispatcher rd=request.getRequestDispatcher(url);
			rd.forward(request, response);
			
			
			
	}
	
		
		
		
}


